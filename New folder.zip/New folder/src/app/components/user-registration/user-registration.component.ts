import { Component, OnInit } from '@angular/core';
import { TravelawayService } from 'src/app/service/travelaway.service';

@Component({
  selector: 'app-user-registration',
  templateUrl: './user-registration.component.html',
  styleUrls: ['./user-registration.component.css']
})
export class UserRegistrationComponent implements OnInit {
  status:boolean;
  errorAddMsg:string;
  msg:string;
  constructor(private _travelawayservice:TravelawayService) { }

  ngOnInit(): void {
  }

  addUser(firstName:string, lastName:string,customerNum:number, emailId:string, gender:string, dob:Date, addInfo:string, password:string) {
    this._travelawayservice.addUser(firstName,lastName,customerNum,emailId,gender,dob,addInfo,password).subscribe(
      response => {
        this.status = response;
        alert("added succesfully");
        
      },
      error => {
        this.errorAddMsg = error;
        this.msg = "some error occured";
        //console.log("error in insert service of rating");
      },
      () => { console.log("Add customer completed"); }
    );
  }

}
