import { TestBed } from '@angular/core/testing';

import { TravelawayService } from './travelaway.service';

describe('TravelawayService', () => {
  let service: TravelawayService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(TravelawayService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
