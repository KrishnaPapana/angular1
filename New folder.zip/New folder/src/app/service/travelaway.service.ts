import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { User } from '../interfaces/user';
@Injectable({
  providedIn: 'root'
})
export class TravelawayService {

  constructor(private http: HttpClient) { }
  addUser(firstName:string, lastName:string, contactNumber:number, emailId:string, gender:string, dob:Date, address:string, password:string): Observable<boolean> {

    let customerObj: User;
    customerObj = { FirstName:firstName, LastName:lastName,EmailId:emailId, Gender:gender, DateOfBirth:dob, Address:address, ContactNumber:contactNumber, UserPassword:password };
    console.log(customerObj)
    let temp = this.http.post<boolean>('https://localhost:44365/api/TravelAway/AddCustomer', customerObj).pipe(catchError(this.errorHandler));
    return temp;
    
  }
  errorHandler(error: HttpErrorResponse) {
    console.error(error);
    return throwError(error.message || 'ERROR')

  } 
}
