import { RouterModule } from '@angular/router';
import { UserRegistrationComponent } from './components/user-registration/user-registration.component';

export var routing = RouterModule.forRoot([
  { path: 'addUser', component: UserRegistrationComponent },
//   { path: '', component: HomeComponent  }


])
