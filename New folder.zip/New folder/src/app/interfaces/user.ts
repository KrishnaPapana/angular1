export interface User {
    FirstName: string;
    LastName:string;
    EmailId: string;
    UserPassword: string;
    Gender: string;
    ContactNumber: number;
    DateOfBirth: Date;
    Address: string;
  }
  