import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { UserRegistrationComponent } from './components/user-registration/user-registration.component';
import { TravelawayService } from './service/travelaway.service';

@NgModule({
  declarations: [
    AppComponent,
    UserRegistrationComponent
  ],
  imports: [
    BrowserModule
  ],
  providers: [TravelawayService],
  bootstrap: [AppComponent]
})
export class AppModule { }
