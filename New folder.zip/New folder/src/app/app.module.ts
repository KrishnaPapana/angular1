import { HttpClientModule } from '@angular/common/http';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { routing } from './app.routing';
import { UserRegistrationComponent } from './components/user-registration/user-registration.component';
import { TravelawayService } from './service/travelaway.service';

@NgModule({
  declarations: [
    AppComponent,
    UserRegistrationComponent
  ],
  imports: [
    BrowserModule,routing,FormsModule,HttpClientModule
  ],
  providers: [TravelawayService,HttpClientModule],
  bootstrap: [AppComponent]
})
export class AppModule { }
